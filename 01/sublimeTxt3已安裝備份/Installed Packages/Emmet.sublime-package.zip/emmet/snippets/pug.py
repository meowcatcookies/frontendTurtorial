snippets = {
	"!!!": "{doctype html}"
}
