# BracketHighlighter 2.30.0

New release!

A restart might be required. If you see issues immediately after the update  
please try restarting.

## 2.30.0

- **NEW**: When defining key bindings `type` is now defaulted to `['__all__']` if not set.
- **FIX**: Ensure Jinja2 support for works for the Jinja2 package (support existed for some older package).
