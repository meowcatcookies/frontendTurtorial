# BracketHighlighter

Welcome to BracketHighlighter!

A restart of Sublime Text is recommended to ensure all dependencies get  
loaded properly.

For a quick start guide, please go to  
`Preferences->Package Settings->BracketHighlighter->Quick Start Guide`.
