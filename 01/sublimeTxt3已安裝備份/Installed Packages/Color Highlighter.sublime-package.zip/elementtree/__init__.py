"""ST2 polyfill for xml.etree.ElementTree."""
