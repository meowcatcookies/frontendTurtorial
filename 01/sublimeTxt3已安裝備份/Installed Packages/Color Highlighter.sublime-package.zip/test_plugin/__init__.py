"""
Test plugin.

A Sublime Text plugin for writing logs into a file.
"""
