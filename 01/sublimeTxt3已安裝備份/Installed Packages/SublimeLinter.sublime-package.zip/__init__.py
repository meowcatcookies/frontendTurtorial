"""Hi.

If you're looking for the public API,
it is over there: `SublimeLinter.lint.__init__.py`
"""
