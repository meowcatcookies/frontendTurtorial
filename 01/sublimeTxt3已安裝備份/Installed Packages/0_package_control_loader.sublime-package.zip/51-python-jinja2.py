from package_control import sys_path
sys_path.add_dependency('python-jinja2')
